package com.example.demo;

import cn.beecp.boot.EnableMultiDataSource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableMultiDataSource
@SpringBootApplication
public class MutilDsApplication {
	public static void main(String[] args) {
		SpringApplication.run(MutilDsApplication.class, args);
	}
}
