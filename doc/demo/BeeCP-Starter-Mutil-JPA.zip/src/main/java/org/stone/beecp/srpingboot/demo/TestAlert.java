package org.stone.beecp.srpingboot.demo;

import org.stone.beecp.springboot.statement.StatementTraceAlert;
import org.stone.beecp.springboot.statement.StatementTrace;

import java.util.List;

public class TestAlert extends StatementTraceAlert {
    public void alert(List<StatementTrace> alertList) {
        System.out.println("....test alert siz:" + alertList.size());
    }
}
