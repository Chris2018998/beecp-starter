package org.stone.beecp.srpingboot.demo;

import org.stone.beecp.srpingboot.demo.entity.UserInfo;
import org.stone.beecp.srpingboot.demo.entity.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.stone.beecp.springboot.annotation.EnableDsMonitor;

import java.util.List;

@EnableDsMonitor
@SpringBootApplication
@RestController
public class SingleDsApplication {
    @Autowired
    private UserInfoService service;

    public static void main(String[] args) {
        SpringApplication.run(SingleDsApplication.class, args);
    }

    @RequestMapping("/getAllUser")
    public List<UserInfo> findLandAttach() throws Exception {
        return service.getAllUserInfo();
    }
}
