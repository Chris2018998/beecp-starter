//package cn.stone.starter.demo;
//
////import org.apache.shiro.SecurityUtils;
////import org.apache.shiro.authc.UsernamePasswordToken;
////import org.apache.shiro.authz.annotation.RequiresPermissions;
////import org.apache.shiro.authz.annotation.RequiresRoles;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
////import com.louis.web.demo.model.Role;
////import com.louis.web.demo.model.User;
////import com.louis.web.demo.service.LoginService;
//
//@RestController
//public class LoginController {
//	/**
//	 * 添加用户
//	 * @param user
//	 * @return
//	 */
//	@PostMapping(value = "/addUser")
//	public String addUser() {
//		//user = loginService.addUser(user);
//		return "addUser is ok! \n";
//	}
//
//	/**
//	 * 添加角色
//	 * @param role
//	 * @return
//	 */
//	@PostMapping(value = "/addRole")
//	public String addRole() {
//		//role = loginService.addRole(role);
//		return "addRole is ok! \n";
//	}
//
//	/**
//	 * 注解的使用
//	 * @return
//	 */
//	@GetMapping(value = "/create")
//	public String create() {
//		return "Create success!";
//	}
//
//	@GetMapping(value = "/index")
//	public String index() {
//		return "index page!";
//	}
//
//	@GetMapping(value = "/error")
//	public String error() {
//		return "error page!";
//	}
//
//	/**
//	 * 退出的时候是get请求，主要是用于退出
//	 * @return
//	 */
//	@GetMapping(value = "/login")
//	public String login() {
//		return "login";
//	}
//
//	@GetMapping(value = "/logout")
//	public String logout() {
//		return "logout";
//	}
//}